
import java.io.*;
import java.util.Scanner;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;

public class Graph {
	

	public static class findNodesMapper extends Mapper<Object,Text,LongWritable,LongWritable> {
        @Override
        public void map ( Object key, Text value, Context context )
                        throws IOException, InterruptedException {
            Scanner s = new Scanner(value.toString()).useDelimiter(",");
            long n = s.nextLong();
            long edges = s.nextLong();
            context.write(new LongWritable(n),new LongWritable(edges));
            s.close();
        }
    }

    public static class findNodesReducer extends Reducer<LongWritable,LongWritable,LongWritable,LongWritable> {
        @Override
        public void reduce ( LongWritable key, Iterable<LongWritable> values, Context context )
                           throws IOException, InterruptedException {
            long cn = 0;
            for (LongWritable v: values) {                
                cn++;
            };
            context.write(key,new LongWritable(cn));
        }
    }

	public static class groupEdgesMapper extends Mapper<Object,Text,LongWritable,LongWritable> {

        @Override
        public void map ( Object key, Text value, Context context )
                        throws IOException, InterruptedException {
            LongWritable one = new LongWritable(1);
            Scanner s = new Scanner(value.toString()).useDelimiter(",");           
			long n = s.nextLong();
            long edges = s.nextLong();
            context.write(new LongWritable(edges),one);
            s.close();
        }
    }
	

    public static class groupEdgesReducer extends Reducer<LongWritable,LongWritable,LongWritable,LongWritable> {
        @Override
        public void reduce ( LongWritable key, Iterable<LongWritable> values, Context context )
                           throws IOException, InterruptedException {
            long total = 0;
            for (LongWritable v: values) {                
                total += v.get();
            };
            context.write(key,new LongWritable(total));
        }
    }
	
	public static void setJobConfigurations(Job job) throws Exception {
		job.setJarByClass(Graph.class);
		job.setMapOutputKeyClass(LongWritable.class);
		job.setMapOutputValueClass(LongWritable.class);
		job.setOutputKeyClass(LongWritable.class);
		job.setOutputValueClass(LongWritable.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
	}


    public static void main ( String[] args ) throws Exception {
		

		Job job1 = Job.getInstance();
        job1.setJobName("Job1");
	    setJobConfigurations(job1);
		Configuration conf = job1.getConfiguration();
		conf.set("mapred.textoutputformat.separator", ",");
		job1.setMapperClass(findNodesMapper.class);
        job1.setReducerClass(findNodesReducer.class);
        FileInputFormat.setInputPaths(job1,new Path(args[0]));
        FileOutputFormat.setOutputPath(job1,new Path(args[1]));

        job1.waitForCompletion(true);
		

		Job job2 = Job.getInstance();
        job2.setJobName("Job2");
	    setJobConfigurations(job2);
		conf = job2.getConfiguration();
		conf.set("mapred.textoutputformat.separator", " ");
		job2.setMapperClass(groupEdgesMapper.class);
        job2.setReducerClass(groupEdgesReducer.class);
        FileInputFormat.setInputPaths(job2,new Path(args[1]));

        FileOutputFormat.setOutputPath(job2,new Path(args[2]));
        job2.waitForCompletion(true);		
    }
}