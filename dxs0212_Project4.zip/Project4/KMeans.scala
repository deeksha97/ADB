import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import scala.io.Source

object KMeans {
	type Point = (Double,Double)

	var centroids: Array[Point] = Array[Point]()

	def main(args: Array[ String ]) {
    /* ... */
	val conf = new SparkConf().setAppName("kmeans");
	val sc = new SparkContext(conf);

	
	
	 
	val r = sc.textFile(args(1))
	centroids = r.map(eL => {val temp = eL.split(",")
													(temp(0).toDouble,temp(1).toDouble).asInstanceOf[Point]}).collect()

  
	for ( i <- 1 to 5 ) {
       val cs11 = sc.broadcast(centroids)
       val k = sc.textFile(args(0))	    
       centroids = k.map(p => {val t = p.split(",")
											(t(0).toDouble,t(1).toDouble)}).map(p=>(distBP(p,cs.value),p)).groupByKey().map(kv => finalC(kv._2)).collect()

    }
	centroids.foreach(println)
  
  
  
	}
	def distKM(p:Point,aP:Array[Point]) = {
		var c=0
		var finalPoint:Point = (0.0,0.0)
		var leastDistance:Double=0
		var dist:Double =0
		for(aPI:Point <- aP){
			dist = math.sqrt(math.pow((p._1-aPI._1),2) + math.pow((p._2-aPI._2),2))
			if(c==0){
				leastDistance = dist
				finalPoint = aPI
				c = c+1
			}
			if(dist<leastDistance){
				leastDistance = dist
				finalPoint = aPI
			}
	  
		}
		finalP
	}

	def finalCentroid(iP:Iterable[Point]) = {
		val c = iP.size
		var mT:Double = 0
		var nT:Double = 0
	
		for(eP:Point <- iP){
			mT = mT + eP._1
			nT = nT + eP._2
		}
		var fmT:Double = mT/c
		var fnT:Double = nT/c
		(fmT,fnT).asInstanceOf[Point]
	
	}


}
