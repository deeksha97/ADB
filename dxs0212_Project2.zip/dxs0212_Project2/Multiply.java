import java.io.DataInput;
import java.io.DataOutput;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;
import org.apache.hadoop.util.ReflectionUtils;

public class Multiply {

	public static class Element implements Writable {
		int d;
		int s;
		double v;

		Element() {

		}

		Element(int d, int s, double v) {
			this.d = d;
			this.s = s;
			this.v = v;
		}

		public void write(DataOutput out) throws IOException {
			out.writeInt(d);
			out.writeInt(s);
			out.writeDouble(v);

		}

		public void readFields(DataInput in) throws IOException {
			d = in.readInt();
			s = in.readInt();
			v = in.readDouble();

		}

	}

	public static class Pair implements WritableDD<Pair> {
		int i;
		int j;

		Pair() {

		}

		Pair(int i, int j) {
			this.i = i;
			this.j = j;
		}

		public void write(DataOutput out) throws IOException {
			out.writeInt(i);
			out.writeInt(j);

		}

		public void readFields(DataInput in) throws IOException {
			i = in.readInt();
			j = in.readInt();

		}

		public int compareTo(Pair pair) {
			if (i > pair.i) {
				return 1;
			} else if (i < pair.i) {
				return -1;
			} else {
				if (j > pair.j) {
					return 1;
				} else if (j < pair.j) {
					return -1;
				}
			}
			return 0;

		}

		public String toString() {
			return i + " " + j + " ";

		}

	}

	public static class D_Matrix extends Mapper<Object, Text, IntWritable, Element> {

		public void map(Object key, Text value, Context con) throws IOException, InterruptedException {
			Scanner s = new Scanner(value.toString()).useDelimiter(",");
			int i = s.nextInt();
			int j = s.nextInt();
			double valueD = s.nextDouble();

			con.write(new IntWritable(j), new Element(0, i, valueD));
			s.close();
		}
	}

	public static class S_Matrix extends Mapper<Object, Text, IntWritable, Element> {

		public void map(Object key, Text value, Context con) throws IOException, InterruptedException {
			Scanner s = new Scanner(value.toString()).useDelimiter(",");
			int j = s.nextInt();
			int i = s.nextInt();
			double valueD = s.nextDouble();
			con.write(new IntWritable(j), new Element(1, i, valueD));
			s.close();
		}
	}

	public static class Reducer_1 extends Reducer<IntWritable, Element, Pair, DoubleWritable> {

		public void reduce(IntWritable key, Iterable<Element> values, Context con)
				throws IOException, InterruptedException {
			ArrayList<Element> l = new ArrayList<Element>();
			ArrayList<Element> m = new ArrayList<Element>();

			Configuration config = con.getConfiguration();
			for (Element e : values) {
				Element temporary = ReflectionUtils.newInstance(Element.class, config);
				ReflectionUtils.copy(config, e, temporary);

				if (e.d == 0) {
					l.add(temporary);
				} else if (e.d == 1) {
					m.add(temporary);
				}
			}

			for (int i = 0; i < l.size(); i++) {
				for (int k = 0; k < m.size(); k++) {
					Pair p = new Pair(m.get(i).s, l.get(k).s);
					Double multiply_Result = m.get(i).v * l.get(k).v;

					con.write(p, new DoubleWritable(multiply_Result));

				}
			}

		}
	}

	public static class MultiplyMap extends Mapper<Object, DoubleWritable, Pair, DoubleWritable> {
		public void map(Object key, Text values, Context con) throws IOException, InterruptedException {
			Scanner s = new Scanner(values.toString()).useDelimiter("\\s+");

			int x = s.nextInt();
			int y = s.nextInt();
			double val = s.nextDouble();

			Pair p = new Pair(x, y);
			con.write(p, new DoubleWritable(val));

		}

	}

	public static class MultiplyRed extends Reducer<Pair, DoubleWritable, Pair, DoubleWritable> {
		public void reduce(Pair key, Iterable<DoubleWritable> values, Context con)
				throws IOException, InterruptedException {
			double reduce_total = 0.0;
			for (DoubleWritable val : values) {
				reduce_total += val.get();
			}
			con.write(key, new DoubleWritable(reduce_total));
		}
	}

	public static boolean deleteTempDir(File directory) {
		if (directory.exists()) {
			File[] files = directory.listFiles();
			if (null != files) {
				for (int i = 0; i < files.length; i++) {
					if (files[i].isDirectory()) {
						deleteTempDir(files[i]);
					} else {
						files[i].delete();
					}
				}
			}
		}
		return (directory.delete());
	}

	public static void main(String[] args) throws Exception {
		File tmp = new File("Intermediate");
		deleteTempDir(tmp);
		Configuration config = new Configuration();
		Job job_1 = Job.getInstance(config, "Job_1");
		job_1.setJarByClass(Multiply.class);
		job_1.setMapOutputKeyClass(IntWritable.class);
		job_1.setMapOutputValueClass(Element.class);

		MultipleInputs.addInputPath(job_1, new Path(args[0]), TextInputFormat.class, D_Matrix.class);
		MultipleInputs.addInputPath(job_1, new Path(args[1]), TextInputFormat.class, S_Matrix.class);

		job_1.setReducerClass(Reducer_1.class);
		job_1.setOutputKeyClass(Pair.class);
		job_1.setOutputValueClass(DoubleWritable.class);

		job_1.setOutputFormatClass(SequenceFileOutputFormat.class);
		SequenceFileOutputFormat.setOutputPath(job_1, new Path(args[2]));

		job_1.waitForCompletion(true);

		Job job_2 = Job.getInstance(config, "Job_2");
		job_2.setJarByClass(Multiply.class);
		job_2.setMapperClass(MultiplyMap.class);
		job_2.setMapOutputKeyClass(Pair.class);
		job_2.setMapOutputValueClass(DoubleWritable.class);

		job_2.setInputFormatClass(SequenceFileInputFormat.class);
		SequenceFileInputFormat.addInputPath(job_2, new Path(args[2]));

		job_2.setReducerClass(MultiplyRed.class);
		job_2.setOutputFormatClass(TextOutputFormat.class);

		FileOutputFormat.setOutputPath(job_2,  new Path(args[3]));

		job_2.waitForCompletion(true);
	}

}

