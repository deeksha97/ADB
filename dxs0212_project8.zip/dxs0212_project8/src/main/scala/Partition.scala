import org.apache.spark.graphx.{Graph, VID, Edge}
import org.apache.spark.graphx.util.GraphGenerators
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD

object Partition {
  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("Partition")
    val sc = new SparkContext(conf)

   
    val edges: RDD[Edge[Long]] = sc
      .textFile(args(0))
      .map(line => {
        val (n, adj) = line.split(",").splitAt(1)
        var VID = n(0).toLong
        (VID, adj.toList.map(_.toLong))
      })
      .flatMap(x => x._2.map(y => (x._1, y)))
      .map(n => {
        Edge(n._1, n._2, 0L)
      })

    
    var flag = 0
    val ff = sc
      .textFile(args(0))
      .map(line => {
        val (n, _) = line.split(",").splitAt(1)
        var v = -1L
        if (flag < 5) {
          v = n(0).toLong
          flag += 1
        }
        v // RDD[Long]
      })

    val fl = ff.filter(_ != -1).collect().toList

    
    val graph: Graph[Long, Long] = Graph
      .fromEdges(edges, 0L)
      .mapVertices((id, _) => {
        var ctroid = -1L
        if (fl.contains(id)) {
          ctroid = id
        }
        ctroid
      })

    val i = graph.pregel(Long.MinValue, 6)(
      (vid, vdata, cluster) => {
        if (vdata == -1) {
          math.max(vdata, cluster)
        } else {
          vdata
        }
      },
      triplet => {
        Iterator((triplet.dstId, triplet.srcAttr))
      },
      (a, b) => math.max(a, b)
    )

 
    var partiSize = i.vertices
      .map {
        case (id, ctroid) =>
          (ctroid, 1)
      }
      .reduceByKey(_ + _)

    partiSize.collect.foreach(println)
  }
}
