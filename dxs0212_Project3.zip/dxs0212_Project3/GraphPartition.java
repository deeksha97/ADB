import java.io.*;
import java.util.Scanner;
import java.util.Vector;
import java.util.Iterator;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;


class V1 implements Writable {

    public long id;                   // the vertex ID
    public Vector<Long> A;     // the vertex neighbors
    public long Centroid_P;             // the id of the Centroid_P in which this vertex belongs to
    public short D;               // the BFS D
    /* ... */

	public V1()
	{
		
	}

	public V1(long input_id, Vector<Long> input_A, long input_Centroid_P, short input_D)
    {
        id = input_id ;
        A = input_A;
        Centroid_P = input_Centroid_P;
        D = input_D;
    }
    
    public void write(DataOutput out) throws IOException
    {
        out.writeLong(id);
        out.writeLong(Centroid_P);
        out.writeShort(D);
        
		int adj_size = A.size();
		out.writeInt(A.size());
		
		for(int i=0; i<adj_size; i++) {
			out.writeLong(A.get(i));
		}
	}
	
	public void readFields(DataInput in) throws IOException
    {
        id = in.readLong();
        Centroid_P = in.readLong(); 
        D = in.readShort();		
        A = new Vector<Long>();
		int adj_size = in.readInt();
		
		for(int i=0; i<adj_size; i++) {
			A.add(in.readLong());
		}
    }
	
	@Override
	public String toString() {
		return "V1 [id=" + id + ", A=" + A + ", Centroid_P=" + Centroid_P + ", D=" + D + "]";
	}
}

public class GraphPartition {
	static int v1_count = 0;
    static Vector<Long> Centroid_Ps = new Vector<Long>();
    final static short max_D = 8;
    static short BFS_D = 0;

    /* ... */


public static class G_Map_1 extends Mapper<Object, Text, LongWritable, V1>
{
     @Override
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException
    {
        long id;
        Scanner scanner = new Scanner(value.toString()).useDelimiter(",");
        id = scanner.nextLong();
		V1 = new V1();
    	v1.id = id;
    	v1.A = new Vector<Long>();
    	v1.D = (short) 0;

		if(v1_count<10) {
   			v1.Centroid_P = id;
    	} else {
   			v1.Centroid_P = -1;
    	}

        while (scanner.hasNext()) {
            v1.A.add(scanner.nextLong());
        }
		
		v1_count++;
        context.write(new LongWritable(id), v1);
		
		scanner.close();
	}
}

public static class G_Map_2 extends Mapper<LongWritable, V1, LongWritable, V1> {

    public void map(LongWritable key, V1 v1, Context context) throws IOException,InterruptedException{
        context.write(new LongWritable(v1.id), v1);

        if (v1.Centroid_P > 0)
        {
            Iterator<Long> neighbours = v1.A.iterator();
			
			while(neighbours.hasNext()) {
				long n = neighbours.next();
				context.write(new LongWritable(n), new V1(n, new V1<Long>(), v1.Centroid_P, BFS_D));;
			}
        }
    }
}

public static class G_Red_2 extends Reducer<LongWritable, V1, LongWritable, V1>{

    @Override
    public void reduce(LongWritable id, Iterable<V1> values, Context context) throws IOException,InterruptedException
    {
        short min_D = 1000;
        V1 m = new V1(id.get(), new Vector<Long>(),(long)(-1),(short)(0));
		
        for(V1 v : values)
        {
            if(!(v.A.isEmpty()))
            {
                m.A = v.A;
            }
            if(v.Centroid_P > 0 && v.D < min_D)
            {
                min_D = v.D;
                m.Centroid_P = v.Centroid_P;
            }
        }
		
        m.D = min_D;
        context.write(id, m);
    }
}

public static class G_Map_3 extends Mapper<LongWritable,V1, LongWritable, IntWritable>{
    @Override
    public void map(LongWritable id, V1 value, Context context) throws IOException,InterruptedException
    {
		context.write(new LongWritable(value.Centroid_P), new IntWritable(1));
    }
}

public static class G_Red_3 extends Reducer<LongWritable, IntWritable, LongWritable, IntWritable>{

    @Override
    public void reduce(LongWritable Centroid_P, Iterable<IntWritable> values, Context context) throws IOException,InterruptedException
    {
        int m = 0;
		
        for (IntWritable v : values)
        {
            m = m + v.get() ;
        }
		
        context.write(Centroid_P, new IntWritable(m));
	}
}

	public static boolean performJob1(String [] args) throws Exception {
		boolean success = false;
		
		Job job = Job.getInstance();
        job.setJobName("Job1");
        job.setJarByClass(GraphPartition.class);
        job.setOutputKeyClass(LongWritable.class);
        job.setOutputValueClass(V1.class);
        job.setMapOutputKeyClass(LongWritable.class);
        job.setMapOutputValueClass(V1.class);
		MultipleInputs.addInputPath(job,new Path(args[0]), TextInputFormat.class, G_Map_1.class);
        job.setOutputFormatClass(SequenceFileOutputFormat.class);        
        FileOutputFormat.setOutputPath(job,new Path(args[1]+"/i0"));	
		success = job.waitForCompletion(true);
		return success;
	}

public static boolean performJob2(String [] args) throws Exception {
	boolean success = false;
	
	for (short i = 0; i < max_D; i++ ) {
            BFS_D++;
            Job job = Job.getInstance();

            job.setJobName("Job2");        
            job.setJarByClass(GraphPartition.class);
            job.setOutputKeyClass(LongWritable.class);
            job.setOutputValueClass(V1.class);
            job.setMapOutputKeyClass(LongWritable.class);
            job.setMapOutputValueClass(V1.class);
            job.setMapperClass(G_Map_2.class);
            job.setReducerClass(G_Red_2.class);
            MultipleInputs.addInputPath(job,new Path(args[1]+"/i"+i), SequenceFileInputFormat.class, G_Map_2.class);
            job.setOutputFormatClass(SequenceFileOutputFormat.class);
            FileOutputFormat.setOutputPath(job,new Path(args[1]+"/i"+(i+1)));
            success = job.waitForCompletion(true);
        }
	
	return success;
}

	public static boolean performJob3(String [] args) throws Exception {
		boolean success = false;
		
		Job job = Job.getInstance();
        job.setJobName("job3");
        job.setJarByClass(GraphPartition.class);
        job.setOutputKeyClass(LongWritable.class);
        job.setOutputValueClass(IntWritable.class);
        job.setMapOutputKeyClass(LongWritable.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setReducerClass(G_Red_3.class);
        MultipleInputs.addInputPath(job,new Path(args[1]+"/i8"), SequenceFileInputFormat.class, G_Map_3.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        FileOutputFormat.setOutputPath(job,new Path(args[2]));
        job.waitForCompletion(true);
		return success;
	}

    public static void main ( String[] args ) throws Exception {
		/* ... First Map-Reduce job to read the graph */
        boolean success = performJob1(args);

		if(success) {
            /* ... Second Map-Reduce job to do BFS */
			success = performJob2(args);
		}

		if(success) {
			/* ... Final Map-Reduce job to calculate the cluster sizes */
			success = performJob3(args);
		}

    }
}


